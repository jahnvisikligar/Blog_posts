---
title: Chat with PDF
subtitle: Building a Conversational AI for PDF Documents
date: '2024-04-07T21:22:54.288Z'
slug: how-to-build-a-langchain-pdf-qna-system
tags:
  - womenwhotech
  - langchain
  - pdf
  - natural-language-processing
  - question-answering
  - conversational-ai
  - chat-gpt
  - openai-api
  - gpt35
  - open-ai
  - llm
  - promptengineering
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1712327387338/e21232bb-6cce-41de-9a22-371c3de5004c.jpeg
---
In this fast-paced life, we have all pondered the possibility of extracting valuable insights from documents on the go. Despite attempts to glean key insights through keyword filtering, we often overlook finer details. The desire to engage in dialogue and delve deeper into document content while saving time and avoiding oversight is a common one. Fortunately, this is now achievable through the integration of LLMs with LangChain. This blog post explores the development of a conversational AI system that enables users to interact with and pose questions directly about the content of PDF documents.

<details data-node-type="hn-details-summary"><summary>Know about Langchain</summary><div data-type="detailsContent">A framework that allows one to seamlessly build applications using LLMs. It simplifies the LLM application lifecycle from development, productionizing and deployment. It offers components for document loading, text splitting, prompting, retrieval, memory management, and chain building. By using LangChain, you can focus on the high-level logic of your application, rather than the low-level details of interacting with the LLM.</div></details>

### ***Building a PDF Q&A System***

The project delves into building a conversational Q&A system to answer questions based on a PDF document. The key steps to be followed are:

* **Loading the document**: Langchain provides `PyPDFLoader` to load PDF documents. The method `load_and_split` allows performing loading and splitting of document texts into small chunks using `RecursiveCharacterTextSplitter`.
    
* **Implementing a Prompt Template**: To get more accurate responses based on the document. A custom prompt template is created that includes context from PDF chunks and the user's question.
    
* **Creating the chat interface**: The `ConversationalRetrievalChain` from LangChain to create the chatbot, which combines the OpenAI language model, the PDF retriever, and the conversation memory.
    
* **Interacting through the interface**: Demonstrate how to use the chatbot by asking it a question and displaying the response.
    

### ***Let's get coding***

Diving into the code and understanding the key components:

1. **Importing the Necessary Libraries**: We start by importing the required libraries, including `PyPDFLoader`, `RecursiveCharacterTextSplitter`, `PromptTemplate`, `ChatOpenAI`, `FAISS`, `OpenAIEmbeddings`, `ConversationBufferMemory`, and `ConversationalRetrievalChain`.
    

```python
#compilation of all libraries
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
import langchain
```

2. **Loading and Splitting the PDF**: This `PyPDFLoader` is used to load the PDF document and split it into smaller chunks with chunk overlap using the `RecursiveCharacterTextSplitter`. Thus, ensuring that the chatbot can efficiently retrieve and process the relevant information from the PDF.
    

```python
langchain.debug=True #used for debugging
loader=PyPDFLoader("input_your.pdf")
pages=loader.load_and_split(RecursiveCharacterTextSplitter(chunk_size=1000,chunk_overlap=100,length_function=len,is_separator_regex=False))
"""to check the splitting and length of the documents, uncomment the below lines."""
#for i in range(0,5):print(i,'Pages response:\n',pages[i])
#print("Total length of pages:",len(pages))
```

3. **Implementing the Prompt Template**: To provide the conversational AI system with clear instructions and formatting for the responses, we create a custom prompt template. This template includes placeholders for the context from the PDF chunks and the user's question and specifies the desired response format.
    

```python
#implementing prompt template for better understanding
#Build prompt
template = """Use the following pieces of context to answer the question at the end.
If you don't know the answer, just say that you don't know, don't try to make up an answer.
Use three sentences maximum. Keep the answer as concise as possible.
Must answer in English language only.
Always say "thanks for asking!" at the end of the answer.
{context}
Question: {question}
Helpful Answer:"""
QA_CHAIN_PROMPT=PromptTemplate(input_variables=["context","question"],template=template)
```

4. **Creating the Conversational system**: We use the `ConversationalRetrievalChain` from LangChain to create the Q&A system. This chain combines the OpenAI language model, the PDF retriever, and the conversation memory. The retriever is created using the FAISS vector store and the OpenAI embeddings, which allows the system to efficiently search and retrieve the relevant information from the PDF.
    

```python
'''performing embedding to store text in a vectorstore. expose this index in a retriever interface
k=value return the top 2 most similar chunks. create a chain to answer questions'''
qa=ConversationalRetrievalChain.from_llm(ChatOpenAI(model_name="gpt-3.5-turbo-0613",temperature=0,openai_api_key="YOUR_API_KEY"),
                                         retriever=FAISS.from_documents(pages, OpenAIEmbeddings(openai_api_key="YOUR_API_KEY")).as_retriever(search_type="similarity",search_kwargs={"k":2}),
                                         memory=ConversationBufferMemory(k=5,memory_key="chat_history",return_messages=True),
                                         combine_docs_chain_kwargs={"prompt":QA_CHAIN_PROMPT},verbose=True)
```

4. **Interacting with the Q&A**: Finally, we demonstrate how to use the Q&A system by asking it a question and displaying the response. The conversational system uses the provided context from the PDF and the user's question to generate a concise and informative answer.
    

```python
chat_history=[]
query="How to measure quality of AI projects?"
result=qa({"question":query,"chat_history":chat_history})
result["answer"]
```

### ***Conclusion***

In this blog post, we've explored how to build a conversational interface to interact with PDF documents using LangChain and OpenAI. By leveraging the power of LLMs and the LangChain framework, a PDF Q&A system has been created that can provide users with relevant information from the document clearly and concisely. This approach can be extended to handle various types of unstructured data and can be a valuable tool for research, analysis, and knowledge sharing.

[Code for creation of Q&A system](https://github.com/jahnvisikligar/NLP_projects/blob/main/Chat_with_PDF/chat_with_pdf_langchain.py)
